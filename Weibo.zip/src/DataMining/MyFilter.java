package DataMining;

public class MyFilter {
	public MyFilter() {
		// TODO Auto-generated constructor stub
	}
	
	public boolean isad(String text){
		return true;
	}
}
