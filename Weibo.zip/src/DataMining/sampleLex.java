package DataMining;

public class sampleLex extends Liexicon {
	private double p;
	private int num;
	public sampleLex(String lex){
		this._lexicon = lex;
		num = 1;
		
	}
	public void updateP(){
		
	}
}
