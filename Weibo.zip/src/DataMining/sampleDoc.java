package DataMining;

public class sampleDoc extends Doc {
	int isad;
	public sampleDoc() {
	}
	public sampleDoc(int isad){
		this.isad = isad;
	}
}
