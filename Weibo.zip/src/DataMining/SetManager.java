package DataMining;

import java.util.List;

public class SetManager {
	int sampleDocNum;
	public SetManager(){
		
	}
	public SetManager(int isad){
		if(isad == Global.ad){
			
		}
		else {
			
		}
	}
	public void beginAnalyzer(){
		
	}
	
	public int sampleNum(){
		return sampleDocNum;
	}
	public List<sampleLex> getlexlist(){
		return null;
	}
	
}
