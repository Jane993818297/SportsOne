package DataAnalyzer;

public class Global {

		public static  int weidu;
		public static  int docNum;
		public static  int _k;

	public static double MAX = 10000000;

	public static DBHander dBer = new DBHander();
}
