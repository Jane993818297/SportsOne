package myweibo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import weibo4j.Comments;
import weibo4j.model.CommentWapper;
import weibo4j.model.Paging;
import weibo4j.model.WeiboException;
public class GetAnita {
	public static void main(String[] args) {
		String access_token = "2.00zIVrXGo8RpiB3a0a08042aPrgnGE"; //arg[0];
		String id = "3998539535339346"; //1470709519860"; //arg[1];
		Comments cm = new Comments(access_token);
		
		try {
			Paging page = new Paging(2);
			CommentWapper comment = cm.getCommentById(id , page ,0);
			//Log.logInfo(comment.toString()); 
			//System.out.println(comment.toString());
			
			//Create file to download data
			File file = new File("C:/SaveFile/Comment2.txt");
			if(!file.exists()){
				file.createNewFile();
			}
			
			FileWriter fw = new FileWriter(file.getAbsolutePath());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(comment.toString());
			bw.close();
			
				
		} catch (WeiboException e) {
			e.printStackTrace();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
