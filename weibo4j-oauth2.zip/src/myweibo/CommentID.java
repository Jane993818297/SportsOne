package myweibo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CommentID {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file = new File("C:/SaveFile/commentIDrel.txt");
		if(!file.exists()){
			file.createNewFile();
		}
		FileWriter fw = new FileWriter(file);
		BufferedWriter bw = new BufferedWriter(fw);
		
		FileReader fr = new FileReader("C:/SaveFile/dataaaa");
		BufferedReader br = new BufferedReader(fr);
		StringBuffer sb = new StringBuffer();
		String comment = null;
		while((comment = br.readLine())!= null){
			sb.append(comment);
		}
		fr.close();
		br.close();
		
		String sr = sb.toString();
		Pattern p = Pattern.compile("");
		Matcher m = p.matcher(sr);
		ArrayList<String> strs = new ArrayList<String>();
		    while(m.find()){
		    	strs.add(m.group(0));
		    }
		
	}

}
