package myweibo;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ReadContent {

	public static void main(String[] args) throws UnsupportedEncodingException {
		// TODO Auto-generated method stub
		StringBuffer test = new StringBuffer("");
		try {
            @SuppressWarnings("resource")
			Scanner in = new Scanner(new File("C:\\SaveFile\\GetCommentFile.txt")); 
            while (in.hasNextLine()) {
                String str = in.nextLine();
                test.append(str);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
		//System.out.println(test); 
		Pattern p = Pattern.compile("(text=)(.*?)(, source=)");  
        Matcher m = p.matcher(test);  
        while(m.find()) { 
        	String newStr = (m.group(0)).toString();
        	String newStr1 = new String(newStr.getBytes(), "utf-8");
            System.out.println(newStr1); 
        }
	}

}
