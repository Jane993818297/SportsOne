package myweibo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import weibo4j.model.CommentWapper;
import weibo4j.model.Paging;
import weibo4j.model.WeiboException;
import weibo4j.Comments;


public class NewGetCommentByID {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			String access_token = "2.00GwZ7NDjxaLDEcce790424fNsaiyB";
			String id = "3998539535339346";
			//得到微博评论条数
			Comments cm = new Comments(access_token);
			CommentWapper comment_count = cm.getCommentById(id);
			long CommentCount = comment_count.getTotalNumber();
			int page_num = (int) (CommentCount/50)+3;
			//Create file to download data 需在C盘创建对应文件夹
			File file = new File("C:/SaveFile/data.txt");
			if(!file.exists()){
				file.createNewFile();
			}
			
			FileWriter fw = new FileWriter(file.getAbsolutePath());
			BufferedWriter bw = new BufferedWriter(fw);
			
			for(int i=1; i<=page_num ; i++){
			Paging page = new Paging(i);
			CommentWapper comment = cm.getCommentById(id , page ,0);
			//Log.logInfo(comment.toString()); 
			//System.out.println(comment.toString());
			
			bw.write(comment.toString());
			
			}
			bw.close();
			fw.close();
				
		} catch (WeiboException e) {
			e.printStackTrace();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}

