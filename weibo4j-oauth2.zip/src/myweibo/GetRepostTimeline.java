package myweibo;

import java.util.List;
//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileWriter;
//import java.io.IOException;

import weibo4j.Timeline;
//import weibo4j.examples.oauth2.Log;
import weibo4j.model.Paging;
import weibo4j.model.Status;
import weibo4j.model.StatusWapper;
import weibo4j.model.WeiboException;

public class GetRepostTimeline {
	public static void main(String[] args) {
		String access_token = "2.00zIVrXGo8RpiB3a0a08042aPrgnGE";//args[0];
		String id = "4006566745098189";//args[1];
		Timeline tm = new Timeline(access_token);
		//设置转发列表页码
		Paging page = new Paging();
		page.setCount(200); //设到每页容量的最大值
		int i=0;   //测试用
		int flag = 200; //控制循环跳出，减少API请求次数
		for(int pageIndex=1; pageIndex<10; pageIndex++)
		{
			page.setPage(pageIndex);
			try {
                if(flag < 190) break;
				StatusWapper status = tm.getRepostTimeline(id, page);
				List<Status> resultList = status.getStatuses(); 
                                flag = resultList.size();
			        if (resultList != null && resultList.size() > 0) {   //如果获取到的内容为空，则退出
			            for (Status s : resultList){
			        	System.out.println(s.getUser().getName());  //对每个转发项的操作都放在这个for each函数里，此处显示转发用户的用户名
						i++;
				    }
			        }else{break;}
			} catch (WeiboException e) {
				e.printStackTrace();
			}
		}
		System.out.println("the number of retwitter catched this time is: " +i);
		
//		try {
//			StatusWapper status = tm.getRepostTimeline(id);
//			Log.logInfo(status.toString());
//			
//			File file = new File("C:/SaveFile/GetRepostFile.txt");
//			if(!file.exists()){
//				file.createNewFile();
//			}
//			
//			FileWriter fw = new FileWriter(file.getAbsolutePath());
//			BufferedWriter bw = new BufferedWriter(fw);
//			bw.write(status.toString());
//			bw.close();
//			
//		} catch (WeiboException e) {
//			e.printStackTrace();
//				
//				
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
}
