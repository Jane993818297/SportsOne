package myweibo;

import weibo4j.Timeline;
import weibo4j.examples.oauth2.Log;
import weibo4j.model.StatusWapper;
import weibo4j.model.WeiboException;

public class GetRepostList {
	public static void main(String[] args) {
		String access_token = "2.00zIVrXGo8RpiB3a0a08042aPrgnGE";//args[0];
		String id = "4006566745098189";//args[1];国安的id是4006218189676080
		Timeline tm = new Timeline(access_token);
		try {
			StatusWapper status = tm.getRepostTimeline(id);
			Log.logInfo(status.toString());
		} catch (WeiboException e) {
			e.printStackTrace();
		}
	}
}
