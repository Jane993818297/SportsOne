package myweibo;

import java.awt.DisplayMode;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jdk.nashorn.tools.Shell;

public class TagCloud {
	  
	
	
	  public static void main(String [] args) {  
		  Map<String, Double> m = new HashMap<String, Double>();   
		  m.put("中国", 0.6);   
		  m.put("华师", 0.4);  
		  m.put("中心", 0.1);  
		  m.put("国家", 0.8);  
		  m.put("米兰", 0.2);   
		  m.put("足球", 0.4);   
		  m.put("伊拉克", 0.3);  
		  m.put("韩国", 0.3);   
		  m.put("博雅", 0.4);  
		  m.put("日本", 0.05);  
		  m.put("美国", 0.3);   
		  m.put("曼联", 0.5);  
		  m.put("篮球", 0.3);   
		  m.put("伊朗", 0.2);   
		  System.out.println(m);  
		  }


}
