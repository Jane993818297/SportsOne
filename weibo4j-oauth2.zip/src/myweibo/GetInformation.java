package myweibo;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashSet;
import java.util.Set;

import weibo4j.Comments;
import weibo4j.Timeline;
import weibo4j.model.CommentWapper;
import weibo4j.model.Paging;
import weibo4j.model.WeiboException;
import weibo4j.org.json.JSONObject;  


public class GetInformation implements Runnable{
	
	public static void main(String[] args){
		GetInformation gif = new GetInformation();
		gif.getComments();
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		GetInformation gif = new GetInformation();
		gif.getComments();
	}
	
	public void getComments(){
		
		String access_token = "2.00zIVrXGo8RpiB3a0a08042aPrgnGE";   //这里放之前申请好的accessToken  
		String mid = "DFlsJmp0u";
		Timeline tm = new Timeline(access_token);
        Comments cm = new Comments(access_token);
        
        try{
        	JSONObject jsonid = tm.queryId(mid, 1,1);
        	String id = jsonid.toString().split("\"")[3];//mid2id

        	Paging page = new Paging();
        	
        	FileOutputStream fos = new FileOutputStream("result.txt", true);
        	FileOutputStream mesfos = new FileOutputStream("message.txt", true);
        	Writer filewriter = new OutputStreamWriter(fos, "utf-8"); 
        	@SuppressWarnings("resource")
			Writer messwriter = new OutputStreamWriter(mesfos, "utf-8");
        	
        	int setsize = 0;
        	for(int i=1;i<15;i++){
        	int num = 1;//start page
//        	while(true){
        		page.setPage(num);
            	
        		CommentWapper comment = cm.getCommentById(id, page, 0);
            	
            	String str = comment.toString();
            	String[] substrs = str.split("createdAt=");
            	
            	Set<String> set = new HashSet<String>();
            	
            	for(String substr : substrs){
            		
            		String[] markstrs = substr.split(",");
            		for(String markstr : markstrs){
            			System.out.println(markstr);
            			
            			if(markstr.startsWith(" text=")){
            				if(!set.contains(markstr)){
            					set.add(markstr);
            					messwriter.write(markstr + "\n");
            				}
            				
            			}
            			filewriter.write(markstr + "\n");
            		}
            		
            		filewriter.write("--------------------------------------------------------------------------------------------------------------- \n");
            	}
            	
            	num++;
            	if(setsize < set.size()){//有新的评论内容
            		setsize = set.size();
            	}else{
            		break;
            	}
            	
        	}
        	
        	filewriter.close();
        }catch(WeiboException e){
        	e.printStackTrace();
        }catch(IOException ioe){
        	ioe.printStackTrace();
        }
        
	
	}


}

