package myweibo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import weibo4j.Comments;
import weibo4j.examples.oauth2.Log;
import weibo4j.model.Comment;
import weibo4j.model.CommentWapper;
import weibo4j.model.Paging;
import weibo4j.model.WeiboException;

public class GetACommentByID {
	public static void main(String[] args) throws IOException {
		String access_token = "2.00zIVrXGo8RpiB3a0a08042aPrgnGE"; //arg[0];
		String id = "4006984396795463";//"4006218189676080";这是国安之前的微博，现在的是评论数608的 //1470709519860"; //arg[1];
		Comments cm = new Comments(access_token);
		Paging page = new Paging();
		page.setCount(200); //设到每页容量的最大值
		int i=0;   //测试用
		int flag = 200; //控制循环跳出，减少API请求次数
		for(int pageIndex=1; pageIndex<10; pageIndex++)
		{
			page.setPage(pageIndex);
			try {
                if(flag < 190) break;
				CommentWapper comment = cm.getCommentById(id, page, 0);
				List<Comment> resultList = comment.getComments(); 
                                flag = resultList.size();
			        if (resultList != null && resultList.size() > 0) {   //如果获取到的内容为空，则退出
			            for (Comment c : resultList){
			        	System.out.println(c.getUser().getName());  //对每个评论项的操作都放在这个for each函数里，此处显示评论用户的用户名
						i++;
						
						File file = new File("C:/SaveFile/GetCommentFile.txt");
						if(!file.exists()){
							try {
								file.createNewFile();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						
						FileWriter fw = new FileWriter(file.getAbsolutePath());
						BufferedWriter bw = new BufferedWriter(fw);
						bw.write(comment.toString());
						bw.close();
				    }
			        }else{break;}
			} catch (WeiboException e) {
				e.printStackTrace();
			}
		}
		System.out.println("the number of retwitter catched this time is: " +i);
		
//		try {
//			CommentWapper comment = cm.getCommentById(id);
//			Log.logInfo(comment.toString());
//			
//			File file = new File("C:/SaveFile/GetCommentFile.txt");
//			if(!file.exists()){
//				file.createNewFile();
//			}
//			
//			FileWriter fw = new FileWriter(file.getAbsolutePath());
//			BufferedWriter bw = new BufferedWriter(fw);
//			bw.write(comment.toString());
//			bw.close();
//		} catch (WeiboException e) {
//			e.printStackTrace();
//			//System.out.println(cm.toString());自己写的打印comment的语句
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
}
