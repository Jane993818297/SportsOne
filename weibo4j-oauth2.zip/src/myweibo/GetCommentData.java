package myweibo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GetCommentData {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file = new File("C:/SaveFile/weibo.txt" );
		if(!file.exists()){
			file.createNewFile();
		}
		//FileWriter fw = new FileWriter(file.getAbsolutePath(),"utf-8");
		FileOutputStream fos = new FileOutputStream(file.getAbsolutePath(),true);
		OutputStreamWriter osw = new OutputStreamWriter(fos, "utf-8");
		BufferedWriter bw = new BufferedWriter(osw);

		//FileReader fr = new FileReader("C:/SaveFile/dataaa.txt");
		FileInputStream fis = new FileInputStream("C:/SaveFile/data.txt");   
		InputStreamReader isr = new InputStreamReader(fis, "utf-8");   
		BufferedReader br = new BufferedReader(isr);
		StringBuffer sb = new StringBuffer();
		String comment = null;
		while((comment = br.readLine())!=null){
			sb.append(comment);
			
		}
		isr.close();
		br.close();
		String sr = sb.toString();
		
		String[] strs = sr.split("]]]");
		for(int i=0;i<strs.length;i++){
			String[] sss = strs[i].split("createdAt=");
			    for(int j=0;j<sss.length;j++){
			    	sss[j]= "Comment [createdAt=" + sss[j];
   
				    Pattern p = Pattern.compile("(?<=Comment \\[createdAt=)(.*?)(?=, id=)");//获取评论时间
				    Matcher m = p.matcher(sss[j].toString());
					while(m.find()){
						String commentTime=m.group(0);
						bw.write(commentTime + ", ");
					}
					
				    Pattern p1 = Pattern.compile("(?<=, id=)(.*?)(?=, mid=)");//获取评论ID
				    Matcher m1 = p1.matcher(sss[j].toString());
						while(m1.find()){
							String commentID = m1.group(0);
							if(commentID.length() == 16){
								bw.write(commentID + ", ");
						    }
						}	
//						
//						
//				    Pattern p2 = Pattern.compile("(?<=, mid=)(.*?)(?=, idstr=)");//获取评论MID
//				    Matcher m2 = p2.matcher(sss[j].toString());
//					    while(m2.find()){
//								String commentMID=m2.group(0);
//								bw.write(commentMID + ", ");
//							}
//				
//			        Pattern p3 = Pattern.compile("(?<=, idstr=)(.*?)(?=, text=)");//获取评论IDstr
//				    Matcher m3 = p3.matcher(sss[j].toString());
//						while(m3.find()){
//								String commentIDstr=m3.group(0);
//								bw.write(commentIDstr + ", ");
//									}	    
//				
				    Pattern p4 = Pattern.compile("(?<=, text=)(.*?)(?=, source=)");	//获取评论内容
				    Matcher m4 = p4.matcher(sss[j].toString());
					    while(m4.find()){
					    	String s = m4.group(0);
					    	String s1 = s.replaceAll("回复\\@\\b.*\\b[:]\\b", " ");     //去掉内容中的以回复@开头，以：结尾的昵称
							String s2 = s1.replaceAll("[\\[].*?[\\]]", " ");                //去掉内容中[]中的内容     
							String s3 = s2.replaceAll("^[\ud83c\udc00-\ud83c\udfff]|[\ud83d\udc00-\ud83d\udfff]|[\u2600-\u27ff]", " ");  // 去掉内容中的表情emoji字符等
							String s4 = s3.replaceAll("[㊗]", " ");
							String s5 = s4.replaceAll("[\\/]{2}\\@\\b.*\\b[:]\\b"," ");    //去掉以//@开头，以:作为结尾的人称
							String s6 = s5.replaceAll("[a-zA-z]+://[^\n]*", " ");          // 去掉http链接
							String commentText = s6.replaceAll("\\@\\b.*[^\n]*", " ");  //去掉@的人名
							bw.write(commentText + ", " + "\n");
					    }
//					    
//					Pattern p5 = Pattern.compile("(?<=nofollow\">)(.*?)(?=</a>)");//获取评论来源客户端或者PC
//					Matcher m5 = p5.matcher(sss[j].toString());
//					    while(m5.find()){
//							String commentSource=m5.group(0);
//							bw.write(commentSource + ", ");
//										}
//					Pattern p6 = Pattern.compile("(?<=\\[id=)(.*?)(?=, screenName=)");//获取评论用户ID
//					Matcher m6 = p6.matcher(sss[j].toString());
//					    while(m6.find()){
//					    	String userID = m6.group(0);
//					    	bw.write(userID + ", ");
//					    }
//					Pattern p7 = Pattern.compile("(?<=, screenName=)(.*?)(?=, name=)");//获取评论用户screenName
//					Matcher m7 = p7.matcher(sss[j].toString());
//						while(m7.find()){
//						    String userScreenName = m7.group(0);
//						    bw.write(userScreenName + ", ");
//						    }
//					Pattern p8 = Pattern.compile("(?<=, name=)(.*?)(?=, province=)");//获取评论用户name
//					Matcher m8 = p8.matcher(sss[j].toString());
//						while(m8.find()){
//							String userName = m8.group(0);
//							bw.write(userName + ", ");
//							    }
//					Pattern p9 = Pattern.compile("(?<=, province=)(.*?)(?=, city=)");//获取评论用户province
//					Matcher m9 = p9.matcher(sss[j].toString());
//						while(m9.find()){
//							String userProv = m9.group(0);
//						    bw.write(userProv + ", ");
//								    }				    
//					Pattern p10 = Pattern.compile("(?<=, city=)(.*?)(?=, location=)");//获取评论用户city
//					Matcher m10 = p10.matcher(sss[j].toString());
//						while(m10.find()){
//							String userCity = m10.group(0);
//							bw.write(userCity + ", ");
//									    }    
//					    
//					Pattern p11 = Pattern.compile("(?<=, location=)(.*?)(?=, description=)");//获取评论用户location
//					Matcher m11 = p11.matcher(sss[j].toString());
//						while(m11.find()){
//							String userLocat = m11.group(0);
//							bw.write(userLocat + ", ");
//										    }    
//					Pattern p12 = Pattern.compile("(?<=, description=)(.*?)(?=, url=)");//获取评论用户description
//					Matcher m12 = p12.matcher(sss[j].toString());
//						while(m12.find()){
//							String userDes = m12.group(0);
//							bw.write(userDes + ", ");
//											    } 	        
//					Pattern p13 = Pattern.compile("(?<=, url=)(.*?)(?=, profileImageUrl=)");//获取评论用户url
//					Matcher m13 = p13.matcher(sss[j].toString());
//						while(m13.find()){
//							String userUrl = m13.group(0);
//							bw.write(userUrl + ", ");
//												    }    
//					Pattern p14 = Pattern.compile("(?<=, profileImageUrl=)(.*?)(?=, userDomain=)");//获取评论用户profile_image_url
//					Matcher m14 = p14.matcher(sss[j].toString());
//						while(m14.find()){
//							String userImgUrl = m14.group(0);
//							bw.write(userImgUrl + ", ");
//													}     
//					Pattern p15 = Pattern.compile("(?<=, userDomain=)(.*?)(?=, gender=)");//获取评论用户域名domain
//					Matcher m15 = p15.matcher(sss[j].toString());
//						while(m15.find()){
//							String userDom = m15.group(0);
//							bw.write(userDom + ", ");
//														}     
//					    
//					Pattern p16 = Pattern.compile("(?<=, gender=)(.*?)(?=, followersCount=)");//获取评论用户域名性别gender
//					Matcher m16 = p16.matcher(sss[j].toString());
//						while(m16.find()){
//							String userGender = m16.group(0);
//							bw.write(userGender + ", ");
//															}    
//					Pattern p17 = Pattern.compile("(?<=, followersCount=)(.*?)(?=, friendsCount=)");//获取评论用户粉丝数followersCount
//					Matcher m17 = p17.matcher(sss[j].toString());
//						while(m17.find()){
//							String userFollCount = m17.group(0);
//							bw.write(userFollCount + ", ");
//																}    
//					    
//					Pattern p18 = Pattern.compile("(?<=, friendsCount=)(.*?)(?=, statusesCount=)");//获取评论用户关注数friendsCount
//					Matcher m18 = p18.matcher(sss[j].toString());
//						while(m18.find()){
//							String userFrienCount = m18.group(0);
//							bw.write(userFrienCount + ", ");
//																}    
//					    
//					Pattern p19 = Pattern.compile("(?<=, statusesCount=)(.*?)(?=, favouritesCount=)");//获取评论用户微博数statusesCount
//					Matcher m19 = p19.matcher(sss[j].toString());
//						while(m19.find()){
//							String userStaCount = m19.group(0);
//							bw.write(userStaCount + ", ");
//																}    
//					    
//					Pattern p20 = Pattern.compile("(?<=, favouritesCount=)(.*?)(?=, createdAt=)");//获取评论用户收藏数favouritesCount
//					Matcher m20 = p20.matcher(sss[j].toString());
//						while(m20.find()){
//							String userFavCount = m20.group(0);
//							bw.write(userFavCount + ", " );
//																}    
//					    
//					Pattern p21 = Pattern.compile("(?<=, verified=)(.*?)(?=, verifiedType=)");//获取评论用户是否是认证用户加V
//					Matcher m21 = p21.matcher(sss[j].toString());
//						while(m21.find()){
//							String userVerif = m21.group(0);
//							bw.write(userVerif + ", ");
//																	}    
//					    
//					Pattern p22 = Pattern.compile("(?<=, avatarLarge=)(.*?)(?=, onlineStatus=)");//获取评论用户头像大图地址
//					Matcher m22 = p22.matcher(sss[j].toString());
//						while(m22.find()){
//							String userAvatar = m22.group(0);
//							bw.write(userAvatar + ", " + "\n");
//																	}    
					    
					    
					    
					    
					    
					    
					    
					    
					    
			    }
			    
				
		     }
		
		bw.close();
		osw.close();
		
	}


}
