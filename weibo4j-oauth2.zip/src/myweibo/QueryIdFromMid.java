package myweibo;

import weibo4j.Timeline;
import weibo4j.examples.oauth2.Log;
import weibo4j.model.WeiboException;
import weibo4j.org.json.JSONObject;

public class QueryIdFromMid {
	public static void main(String[] args) {
		String access_token = "2.00zIVrXGo8RpiB3a0a08042aPrgnGE";//args[0];
		String mid = "E47fQ1Pag";//args[1];4009812020435008 登巴巴那条
		Timeline tm = new Timeline(access_token);
		try {
			JSONObject id = tm.queryId( mid, 1,1);
			Log.logInfo(id.toString());
		} catch (WeiboException e) {
			e.printStackTrace();
		}

	}
}
