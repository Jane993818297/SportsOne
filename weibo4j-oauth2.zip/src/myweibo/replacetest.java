package myweibo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class replacetest {
		public static void main(String[] args){
			List<String> list = new ArrayList<String>();
	        try
	        {
	        	File file1 = new File("C:/SaveFile/exresult.txt");
				if(!file1.exists())
				{
					file1.createNewFile();
				}
				FileWriter fw = new FileWriter(file1.getAbsolutePath());
				BufferedWriter bw = new BufferedWriter(fw);
	        	
	            String encoding = "utf-8";
	            File file = new File("C:/SaveFile/extractedcomment.txt");
	            if (file.isFile() && file.exists())
	            { // 判断文件是否存在
	                InputStreamReader read = new InputStreamReader(
	                        new FileInputStream(file), encoding);// 考虑到编码格式
	                BufferedReader bufferedReader = new BufferedReader(read);
	                String lineTxt = null;

	                while ((lineTxt = bufferedReader.readLine()) != null)
	                {
	                    list.add(lineTxt);
	                }
	                bufferedReader.close();
	                read.close();
	            }
	            else
	            {
	                System.out.println("找不到指定的文件");
	            }
	            String ss = list.toString();  
	            
	            Set<String> set = new HashSet<String>();
	      
		            Pattern p = Pattern.compile("\\b回复@[\\s\\S].*?\\:\\b");//去掉内容中的以回复@开头，以：结尾的昵称
				    Matcher m = p.matcher(ss);
				    String s=m.replaceAll(" ");
				
		            Pattern p1 = Pattern.compile("[\\/]{2}\\@\\b.*?\\b[:]\\b");//去掉以//@开头，以:作为结尾的人称
				    Matcher m1 =p1.matcher(s);
				    String s1=m1.replaceAll(" ");
				
				    Pattern p2 = Pattern.compile("\\b@[\\s\\S].*?\\：\\b");//去掉以@开头，以：作为结尾的人称
				    Matcher m2 =p2.matcher(s1);
				    String s2=m2.replaceAll(" ");
				
		            Pattern p3 = Pattern.compile("[\\[][^\\[\\]]+[\\]]");//去掉内容中[]中的内容
				    Matcher m3 = p3.matcher(s2);
				    String s3=m3.replaceAll(" ");
				
		            Pattern p4 = Pattern.compile("[^\\u0000-\\uFFFF]");//去掉内容中的表情emoji字符等
			        Matcher m4 =p4.matcher(s3);
			        String s4=m4.replaceAll(" ");
				
			        Pattern p5 = Pattern.compile("^[\ud83c\udc00-\ud83c\udfff]|[\ud83d\udc00-\ud83d\udfff]|[\u2600-\u27ff]");//去掉内容中的表情emoji字符等
			        Matcher m5 =p5.matcher(s4);
			        String s5=m5.replaceAll(" ");
			        String s6 = s5.replaceAll("[a-zA-z]+://[^\n]*", " ");//去掉http链接
			        String s7 = s6.replaceAll("\\b@[\\s\\S].*?\\,\\b", " ");//去掉@的人名
			        String s8 = s7.replaceAll("\\@\\b.*[^\n]*", " ");
			        set.add(s8);
			 //System.out.println(s5);
	           
				for(Iterator<String> itor = set.iterator(); itor.hasNext();)
				{
					//System.out.println(itor.next());
					bw.write(itor.next());
					bw.newLine();		
				}
				
				bw.close();
				fw.close(); 
	            
	        }
	        catch (Exception e)
	        {
	            System.out.println("读取文件内容出错");
	            e.printStackTrace();
	        }    
		
		}
		
	    
	}

