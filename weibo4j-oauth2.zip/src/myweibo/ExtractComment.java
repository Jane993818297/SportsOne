package myweibo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractComment {
public static void main(String[] args) {
	try {
		
		File file = new File("C:/SaveFile/111time.txt" );
		if(!file.exists()){
			file.createNewFile();
		}
		FileWriter fw = new FileWriter(file.getAbsolutePath(), true);
		BufferedWriter bw = new BufferedWriter(fw);

		FileReader fr = new FileReader("C:/SaveFile/data.txt");
		BufferedReader br = new BufferedReader(fr);
		StringBuffer sb = new StringBuffer();
		String comment = null;
		while((comment = br.readLine())!=null){
			sb.append(comment);
			
		}
		fr.close();
		br.close();
		
		//System.out.println(sb);
		String sr = sb.toString();
		//获取内容中的发布评论的时间
		String[] strs = sr.split("]]]");
		for(int i=0;i<strs.length;i++){
			String[] sss = strs[i].split("createdAt=");
		    for(int j=0;j<sss.length;j++){
		    	sss[j]= "Comment [createdAt=" + sss[j];

			    Pattern p = Pattern.compile("(?<=Comment \\[createdAt=)(.*?)(?=, id=)");//获取评论时间
			    Matcher m = p.matcher(sss[j].toString());
				while(m.find()){
					String commentTime=m.group(0);
					bw.write(commentTime + "\n");
				}
						
		}
		
			
		}
		bw.close();
		fw.close();
		
		//--------------------------------------------------
		//System.out.print(strs.get(0).length());
		
		//System.out.println(strs.toString());
	
//		String[] strs = sr.split("text=");
//		Set<String> set = new HashSet<String>();
//		
//		for(int j=0;j< strs.length;j++){	
//			String[] sss = strs[j].split(", source");
//			//set.add(sss[0]);
//			
//			//without @ and emotions
//			String s = sss[0].replaceAll("回复\\@\\b.*?\\b[:]\\b", " ");     //回复@   ：
//			String s1 = s.replaceAll("[\\[].*?[\\]]", " ");                //[  ][  ][  ]      
//			String s2 = s1.replaceAll("^[\ud83c\udc00-\ud83c\udfff]|[\ud83d\udc00-\ud83d\udfff]|[\u2600-\u27ff]", " ");    //emotion
//			String s3 = s2.replaceAll("[㊗]", " ");
//			String s4 = s3.replaceAll("[\\/]{2}\\@\\b.*\\b[:]\\b"," ");    // //@
//			String s5 = s4.replaceAll("[a-zA-z]+://[^\n]*", " ");          // http
//			String s6 = s5.replaceAll("\\@\\b.*?[^\n]*", " ");			
//		
//			set.add(s6);			
//		}
		//------------------------------------------------------------

	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}

}
