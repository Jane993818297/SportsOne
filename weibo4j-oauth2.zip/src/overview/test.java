package overview;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import weibo4j.Comments;
import weibo4j.model.WeiboException;

public class test {
	public static void main(String[] args) {
		String access_token = "2.00GwZ7NDjxaLDEcce790424fNsaiyB";
		String id = "3998539535339346";
		Data da = new Data();
		
		
		//Comments cm = new Comments(access_token);
		//da.DownloadData(cm,id);
		File f = new File("C:/SaveFile/data.txt");
		try {
			FileReader fr = new FileReader(f);
			//da.ExtractComment(fr);
			da.GetCommentTime(fr);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
