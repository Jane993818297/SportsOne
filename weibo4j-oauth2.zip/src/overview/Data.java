package overview;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import weibo4j.Comments;
import weibo4j.Timeline;
import weibo4j.examples.oauth2.Log;
import weibo4j.model.CommentWapper;
import weibo4j.model.Paging;
import weibo4j.model.Status;
import weibo4j.model.WeiboException;
import weibo4j.org.json.JSONArray;

public class Data {
	public String access_token;
	public String id;
	public Comments cm =null;
	

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Comments getCm() {
		return cm;
	}

	public void setCm(Comments cm) {
		this.cm = cm;
	}

	public Data(String access_token,String id) {
		// TODO Auto-generated constructor stub
		access_token = this.access_token;
		id = this.id;
		this.cm = new Comments(this.access_token);
		Comments  cm = new Comments(this.access_token);
		
	}
	
	public Data() {
		// TODO Auto-generated constructor stub
	}
	
	//微博评论条数
	public long GetCommentCount(Comments cm, String id) throws WeiboException{
		CommentWapper comment_count = cm.getCommentById(id);
		System.out.println(comment_count.getTotalNumber());
		return comment_count.getTotalNumber();
	}
	
	public void DownloadData(Comments cm, String id){
		try {
			//得到微博评论条数
			CommentWapper comment_count = cm.getCommentById(id);
			long CommentCount = comment_count.getTotalNumber();
			int page_num = (int) (CommentCount/50)+3;
			//Create file to download data 需在C盘创建对应文件夹
			File file = new File("C:/SaveFile/data.txt");
			if(!file.exists()){
				file.createNewFile();
			}
			
			FileWriter fw = new FileWriter(file.getAbsolutePath());
			BufferedWriter bw = new BufferedWriter(fw);
			
			for(int i=1; i<=page_num ; i++){
			Paging page = new Paging(i);
			CommentWapper comment = cm.getCommentById(id , page ,0);
			//Log.logInfo(comment.toString()); 
			//System.out.println(comment.toString());
			
			bw.write(comment.toString());
			
			}
			bw.close();
			fw.close();
				
		} catch (WeiboException e) {
			e.printStackTrace();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	
	
	//提取评论内容
	public void ExtractComment(FileReader fr) throws IOException{
		BufferedReader br = new BufferedReader(fr);
		StringBuffer sb = new StringBuffer();
		String everyline = null;
		while((everyline = br.readLine())!=null){
			sb.append(everyline);
		}
		fr.close();
		br.close();
		
		String sr = sb.toString();
		String[] strs = sr.split("text=");
		Set<String> set = new HashSet<String>();
		
		for(int j=1;j< strs.length;j++){	
			String[] sss = strs[j].split(", source");
			
			//without @ and emotions
			String s = sss[0].replaceAll("回复\\@\\b.*\\b[:]\\b", " ");     //回复@   ：
			String s1 = s.replaceAll("[\\[].*?[\\]]", " ");                //[  ][  ][  ]      
			String s2 = s1.replaceAll("^[\ud83c\udc00-\ud83c\udfff]|[\ud83d\udc00-\ud83d\udfff]|[\u2600-\u27ff]", " ");    //emotion
			String s3 = s2.replaceAll("[㊗]", " ");
			String s4 = s3.replaceAll("[\\/]{2}\\@\\b.*\\b[:]\\b"," ");    // //@
			String s5 = s4.replaceAll("[a-zA-z]+://[^\n]*", " ");          // http
			String s6 = s5.replaceAll("\\@\\b.*[^\n]*", " ");
			set.add(s6);
			
		}
		File file1 = new File("C:/SaveFile/extracteddata.txt");
		if(!file1.exists()){
			file1.createNewFile();
		}
		FileWriter fw = new FileWriter(file1.getAbsolutePath());
		BufferedWriter bw = new BufferedWriter(fw);
		
		for(Iterator<String> itor = set.iterator(); itor.hasNext();){
			//System.out.println(itor.next());
			bw.write(itor.next());
			bw.newLine();
				
		}
				
		bw.close();
		fw.close();	
	}
	
	//提取每条评论的时间
	public void GetCommentTime(FileReader fr) throws IOException{
		File file = new File("C:/SaveFile/CommentTime.txt" );
		if(!file.exists()){
			file.createNewFile();
		}
		FileWriter fw = new FileWriter(file.getAbsolutePath(), true);
		@SuppressWarnings("resource")
		BufferedWriter bw = new BufferedWriter(fw);
		
		BufferedReader br = new BufferedReader(fr);
		StringBuffer sb = new StringBuffer();
		String everyline = null;
		while((everyline = br.readLine())!=null){
			sb.append(everyline);
		}
		fr.close();
		br.close();

		String sr = sb.toString();
		Pattern p1 = Pattern.compile("((?<=CommentWapper \\[comments=\\[Comment \\[createdAt=)(.*?)(?=, id=))|((?<= Comment \\[createdAt=)(.*?)(?=, id=))");
		Matcher m1 = p1.matcher(sr);
		ArrayList<String> strs = new ArrayList<String>();
			while(m1.find()){
				strs.add(m1.group(0));
				
			}		
			for(int i=0;i<strs.size();i++){
				//System.out.println(strs.get(i).toString());
//				System.out.println("---- " + i + " ----" + strs.get(i).length());
				if(strs.get(i).length() == 28){
					bw.write(strs.get(i).toString() + "\n");
					//System.out.println("---- " + i + " ----" + strs.get(i).length());
			    }		
	}
		
			bw.close();
			fw.close();	
	}
}
