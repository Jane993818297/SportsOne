package overview;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.Policy.Parameters;
import java.util.ArrayList;
import java.util.List;

import weibo4j.Account;
import weibo4j.Timeline;
import weibo4j.model.WeiboException;
import weibo4j.org.json.JSONArray;
import weibo4j.org.json.JSONException;
import weibo4j.org.json.JSONObject;

//通过某条微博的ID号返回该条微博的转发数，评论数，点赞数
public class GetStatusesCount {
	public static void main(String[] args) throws JSONException {
		String access_token = "2.00zIVrXGo8RpiB3a0a08042aPrgnGE";//args[0];
		String ids = "3998539535339346";//args[1]国安的微博id;

		///////////////////////////////////////////////////////
//		boolean netflag = false;
//		System.getProperties().setProperty("proxySet", "true");
//		System.getProperties().setProperty("http.proxyHost", "proxy.pek.sap.corp");
//		System.getProperties().setProperty("http.proxyPort", "8080");
//		HttpURLConnection connection;
//		try {
//			connection = (HttpURLConnection) new URL("http://open.weibo.com").openConnection();
//			connection.setConnectTimeout(6000);
//			connection.setReadTimeout(6000);
//			connection.setUseCaches(false);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		
//		try{
//			Account account = new Account(access_token);
//			JSONObject uid = account.getUid();
//			if(uid.toString() != null){
//				netflag = true;
//			}
//		}catch(WeiboException e){
//			e.printStackTrace();
//		}
		
		//////////////////////////////////////////////////////
		
		
		
		Timeline tm = new Timeline(access_token);
		try {
			    JSONArray json = tm.getStatusesCount(ids);
				System.out.println("--------------"+ json.getString(0));
				JSONObject jo = json.getJSONObject(0);
				String string = jo.toString();
			
				
				
				String[] count = new String[4];
				
				String[] strf = string.split(",");
				for(int i=0;i<strf.length;i++){
					String[] strs = strf[i].split(":");
					for(int j=0;j<strs.length;j++){		
						//System.out.println("str---" + strs[j]);	
						count[i] = strs[1];
						
					}
				}
				String commentsCount = count[0];
				String likeCount = count[1];
				String repostsCount = count[3];
				System.out.println(commentsCount + likeCount + repostsCount);
		} catch (WeiboException e) {
			e.printStackTrace();
		}

	}
}
